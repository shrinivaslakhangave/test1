package com.synechron.org.kafkademos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaDemosApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaDemosApplication.class, args);
	}

}
